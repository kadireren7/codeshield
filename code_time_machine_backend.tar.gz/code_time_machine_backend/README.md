# Code Time Machine Backend

This is a production-oriented backend starter project for the "Code Time Machine" AI tool, designed to analyze user-submitted code and predict future production failures. It is built using Python FastAPI, emphasizing a modular folder structure, asynchronous processing, and extensibility.

## Features

- **FastAPI Framework:** High-performance, asynchronous API development.
- **Modular Structure:** Organized into `api`, `core`, `schemas`, `services`, and `workers` for clean separation of concerns.
- **Asynchronous Processing:** Utilizes FastAPI's `BackgroundTasks` to simulate background analysis processing, ready for integration with message queues like RabbitMQ or Kafka.
- **Code Analysis Endpoint:** `POST /api/v1/analyze` to accept code input and initiate analysis.
- **Structured Response:** Returns a structured analysis response with `request_id`, `status`, and potential `results`.
- **Containerization Ready:** Includes a `Dockerfile` for easy deployment with Docker and Kubernetes.
- **Environment Configuration:** `.env.example` for managing environment-specific settings.

## Folder Structure

```
code_time_machine_backend/
├── app/
│   ├── api/
│   │   ├── endpoints/
│   │   │   ├── __init__.py
│   │   │   └── analysis.py
│   │   └── __init__.py
│   ├── core/
│   │   └── __init__.py
│   ├── schemas/
│   │   └── __init__.py
│   ├── services/
│   │   ├── __init__.py
│   │   └── analysis_service.py
│   ├── workers/
│   │   └── __init__.py
│   └── main.py
├── .env.example
├── Dockerfile
├── requirements.txt
└── README.md
```

## Setup and Run

1.  **Clone the repository:**
    ```bash
    git clone <repository_url>
    cd code_time_machine_backend
    ```

2.  **Create a virtual environment and install dependencies:**
    ```bash
    python -m venv venv
    source venv/bin/activate
    pip install -r requirements.txt
    ```

3.  **Run the application:**
    ```bash
    uvicorn app.main:app --host 0.0.0.0 --port 8000 --reload
    ```
    The API will be available at `http://localhost:8000`.

4.  **Access API Documentation:**
    - Swagger UI: `http://localhost:8000/docs`
    - ReDoc: `http://localhost:8000/redoc`

## Docker

To build and run the application using Docker:

1.  **Build the Docker image:**
    ```bash
    docker build -t code-time-machine-backend .
    ```

2.  **Run the Docker container:**
    ```bash
    docker run -d --name ctm-backend -p 8000:8000 code-time-machine-backend
    ```

## Example Request and Response

### Request (POST /api/v1/analyze)

```json
{
  "code": "def factorial(n):\n    if n == 0:\n        return 1\n    else:\n        return n * factorial(n-1)",
  "language": "python",
  "analysis_types": ["performance", "maintainability"]
}
```

### Response (202 Accepted)

```json
{
  "request_id": "a1b2c3d4-e5f6-7890-1234-567890abcdef",
  "status": "pending",
  "message": "Code analysis initiated. Results will be available shortly."
}
```

### Example Response (after analysis completion - hypothetical GET /api/v1/analysis/{request_id})

```json
{
  "request_id": "a1b2c3d4-e5f6-7890-1234-567890abcdef",
  "status": "completed",
  "results": [
    {
      "type": "performance",
      "severity": "medium",
      "message": "Recursive factorial function can lead to stack overflow for large inputs.",
      "line_number": 5,
      "recommendation": "Consider an iterative approach for better performance and stack safety."
    },
    {
      "type": "maintainability",
      "severity": "low",
      "message": "Function lacks docstrings.",
      "line_number": 1,
      "recommendation": "Add a docstring to explain the function's purpose, arguments, and return value."
    }
  ]
}
```
