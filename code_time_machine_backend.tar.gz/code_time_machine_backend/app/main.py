
from fastapi import FastAPI
from app.api.endpoints import analysis

app = FastAPI(
    title="Code Time Machine API",
    description="AI-powered code analysis to predict production failures.",
    version="0.1.0",
)

app.include_router(analysis.router, prefix="/api/v1", tags=["analysis"])

@app.get("/", tags=["root"])
async def read_root():
    return {"message": "Welcome to Code Time Machine API"}
