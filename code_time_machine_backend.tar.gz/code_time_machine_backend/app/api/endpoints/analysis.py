
from fastapi import APIRouter, HTTPException, BackgroundTasks
from pydantic import BaseModel, Field
from typing import List, Optional
import uuid

from app.services.analysis_service import AnalysisService

router = APIRouter()

class CodeAnalysisRequest(BaseModel):
    code: str = Field(..., min_length=10, description="User-submitted code for analysis.")
    language: str = Field("python", description="Programming language of the submitted code.")
    analysis_types: List[str] = Field(
        ["scaling", "performance", "memory", "maintainability"],
        description="Types of analysis to perform."
    )

class AnalysisResultDetail(BaseModel):
    type: str = Field(..., description="Type of analysis (e.g., performance, memory).")
    severity: str = Field(..., description="Severity of the finding (e.g., high, medium, low).")
    message: str = Field(..., description="Detailed message about the finding.")
    line_number: Optional[int] = Field(None, description="Line number in the code where the finding was identified.")
    recommendation: Optional[str] = Field(None, description="Suggested recommendation to address the finding.")

class CodeAnalysisResponse(BaseModel):
    request_id: str = Field(..., description="Unique ID for the analysis request.")
    status: str = Field(..., description="Current status of the analysis (e.g., pending, in_progress, completed, failed).")
    results: Optional[List[AnalysisResultDetail]] = Field(None, description="List of analysis findings if completed.")
    message: Optional[str] = Field(None, description="Additional message or error details.")

@router.post("/analyze", response_model=CodeAnalysisResponse, status_code=202)
async def analyze_code(request: CodeAnalysisRequest, background_tasks: BackgroundTasks):
    request_id = str(uuid.uuid4())
    
    # Simulate storing the request and starting analysis in the background
    # In a real scenario, this would involve saving to DB and pushing to a message queue
    analysis_service = AnalysisService()
    background_tasks.add_task(analysis_service.start_analysis, request_id, request.code, request.language, request.analysis_types)
    
    return CodeAnalysisResponse(
        request_id=request_id,
        status="pending",
        message="Code analysis initiated. Results will be available shortly."
    )
